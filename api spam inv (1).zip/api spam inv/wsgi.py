from app import app

if __name__ == '__main__':
    app.run(debug=True)
#this code was made by cutehack
#this code was made by cutehack
