from wsgi import app

#this code was made by cutehack
#this code was made by cutehack
#this code was made by cutehack
#this code was made by cutehack
#this code was made by cutehack
#this code was made by cutehack
#this code was made by cutehack
#this code was made by cutehack
#this code was made by cutehack
#this code was made by cutehack
